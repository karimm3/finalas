package com.test.entities;

import javax.persistence.*;

@Entity
public class Company {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;
	    private int yearOfEstablishment;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getYearOfEstablishment() {
			return yearOfEstablishment;
		}
		public void setYearOfEstablishment(int yearOfEstablishment) {
			this.yearOfEstablishment = yearOfEstablishment;
		}
		public Company(Long id, String name, int yearOfEstablishment) {
			super();
			this.id = id;
			this.name = name;
			this.yearOfEstablishment = yearOfEstablishment;
		}
		public Company() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Company [id=" + id + ", name=" + name + ", yearOfEstablishment=" + yearOfEstablishment + "]";
		}
	
	    
	    
}
